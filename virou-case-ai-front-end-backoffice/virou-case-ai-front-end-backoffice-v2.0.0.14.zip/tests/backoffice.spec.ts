import { expect, test, type Page } from "@playwright/test";

async function login(page: Page) {
  await page.goto("/");
  await page.getByLabel("Login", { exact: true }).fill("operator-e2e");
  await page
    .getByLabel("Senha", { exact: true })
    .fill("e2e-operator-only-password");
  await page.getByRole("button", { name: "Entrar no backoffice" }).click();
  await expect(
    page.getByRole("heading", { name: "Contas e acesso" }),
  ).toBeVisible();
}

test("senha gerada, cadastro, ativação e ajuste do prazo preservam o saldo", async ({
  page,
  context,
}, info) => {
  await context.grantPermissions(["clipboard-read", "clipboard-write"]);
  await login(page);
  await page
    .getByRole("button", { name: "Criar usuário", exact: true })
    .click();
  let dialog = page.getByRole("dialog");
  await dialog.getByLabel("Nome", { exact: true }).fill("Aluno prazo E2E");
  await dialog.getByLabel("Login", { exact: true }).fill("access-duration-e2e");
  await dialog.getByRole("button", { name: "Gerar senha" }).click();
  const password = await dialog
    .getByLabel("Senha inicial / nova senha", { exact: true })
    .inputValue();
  expect(password).toHaveLength(24);
  expect(password).toMatch(/[A-Z]/);
  expect(password).toMatch(/[a-z]/);
  expect(password).toMatch(/[0-9]/);
  expect(password).toMatch(/[^a-zA-Z0-9]/);
  await dialog.getByRole("button", { name: "Copiar senha" }).click();
  expect(await page.evaluate(() => navigator.clipboard.readText())).toBe(
    password,
  );
  await page.screenshot({
    path: info.outputPath("create-user.png"),
    fullPage: true,
  });
  await dialog.getByRole("button", { name: "Revisar operação" }).click();
  await expect(dialog).not.toContainText(password);
  await dialog.getByRole("button", { name: "Revisar campos" }).click();
  await expect(dialog.getByLabel("Nome", { exact: true })).toHaveValue(
    "Aluno prazo E2E",
  );
  await expect(
    dialog.getByLabel("Senha inicial / nova senha", { exact: true }),
  ).toHaveValue(password);
  await dialog.getByRole("button", { name: "Revisar operação" }).click();
  await dialog.getByRole("button", { name: "Confirmar e registrar" }).click();
  await expect(dialog).toHaveCount(0);
  const account = page
    .locator("article")
    .filter({ has: page.getByRole("heading", { name: "Aluno prazo E2E" }) });
  await account
    .getByRole("button", { name: "Ativar / renovar", exact: true })
    .click();
  dialog = page.getByRole("dialog");
  await dialog.getByLabel("Período de acesso (dias)").fill("45");
  await page.screenshot({
    path: info.outputPath("activate-access.png"),
    fullPage: true,
  });
  await dialog.getByRole("button", { name: "Revisar operação" }).click();
  await expect(dialog).toContainText("Dias de acesso");
  await dialog.getByRole("button", { name: "Confirmar e registrar" }).click();
  await expect(dialog).toHaveCount(0);
  await expect(account).toContainText("Acesso ativo");
  await expect(account).toContainText("Uso da plataforma até");
  await account
    .getByRole("button", { name: "Ajustes da conta", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Período de acesso", exact: true })
    .click();
  const date = new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 16);
  await page.getByLabel("Uso da plataforma até", { exact: true }).fill(date);
  await page.getByRole("button", { name: "Revisar operação" }).click();
  await page.getByRole("button", { name: "Confirmar e registrar" }).click();
  await expect(page.getByRole("dialog")).toHaveCount(0);
  await account.getByRole("button", { name: "Ver saldo" }).click();
  await expect(page.getByRole("dialog")).toContainText("50,00000000");
});

test("IA: configurar, descobrir, testar, habilitar e desabilitar um modelo", async ({
  page,
}, info) => {
  await login(page);
  await page
    .getByRole("button", { name: "Agentes de IA", exact: true })
    .click();
  await page.getByRole("button", { name: "Nova conexão", exact: true }).click();
  let dialog = page.getByRole("dialog");
  await dialog.getByLabel("Nome da conexão").fill("OpenAI contrato E2E");
  await dialog
    .getByLabel("API key", { exact: true })
    .fill("synthetic-e2e-credential-no-real-key");
  await dialog.getByRole("button", { name: "Salvar configuração" }).click();
  await expect(dialog).toHaveCount(0);
  await page.getByRole("button", { name: "Adicionar modelo" }).click();
  dialog = page.getByRole("dialog");
  await dialog
    .getByRole("button", { name: "Consultar modelos do provedor" })
    .click();
  await expect(dialog).toContainText("1 modelos encontrados");
  await dialog
    .getByLabel("Identificador do modelo")
    .fill("synthetic-text-model");
  await dialog
    .getByLabel("Nome para identificação")
    .fill("Modelo principal E2E");
  await dialog.getByLabel("Entrada (USD)", { exact: true }).fill("0.1");
  await dialog.getByLabel("Entrada em cache (USD)").fill("0.01");
  await dialog.getByLabel("Saída (USD)").fill("0.5");
  await dialog.getByLabel("Câmbio (BRL por USD)").fill("5");
  await dialog.getByLabel("Fonte do câmbio").fill("Cotação sintética de teste");
  await dialog
    .getByLabel("Referência dos preços")
    .fill("Tabela sintética de teste");
  await dialog
    .getByLabel("Fim da vigência")
    .fill(new Date(Date.now() + 86400000).toISOString().slice(0, 16));
  await expect(
    dialog.getByLabel("Habilitar para uso na plataforma"),
  ).toBeDisabled();
  await dialog.getByRole("button", { name: "Salvar configuração" }).click();
  await expect(dialog).toHaveCount(0);
  await page
    .getByRole("button", { name: "Testar geração", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Confirmar teste com possível cobrança" })
    .click();
  await expect(page.getByRole("status")).toContainText("Teste concluído");
  await page.getByRole("button", { name: "Editar modelo" }).click();
  await page.getByLabel("Habilitar para uso na plataforma").check();
  await page.getByRole("button", { name: "Salvar configuração" }).click();
  await expect(
    page.getByText("Pronto para uso", { exact: true }),
  ).toBeVisible();
  await page.screenshot({
    path: info.outputPath("ai-ready.png"),
    fullPage: true,
  });
  await page.getByRole("button", { name: "Editar conexão" }).click();
  await expect(page.getByLabel("API key", { exact: true })).toHaveValue("");
  await page.getByLabel("Conexão habilitada").uncheck();
  await page.getByRole("button", { name: "Salvar configuração" }).click();
  await expect(
    page.getByText("Conexão desabilitada", { exact: true }),
  ).toBeVisible();
});

for (const width of [320, 375, 768, 1024, 1440]) {
  test(`formulários legíveis e sem rolagem horizontal em ${width}px`, async ({
    page,
  }, info) => {
    await page.setViewportSize({ width, height: 900 });
    await login(page);
    await page
      .getByRole("button", { name: "Criar usuário", exact: true })
      .click();
    await expect(
      page.getByRole("button", { name: "Gerar senha" }),
    ).toBeVisible();
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= window.innerWidth,
      ),
    ).toBeTruthy();
    await page.keyboard.press("Escape");
    await page
      .getByRole("button", { name: "Agentes de IA", exact: true })
      .click();
    await page
      .getByRole("button", { name: "Nova conexão", exact: true })
      .click();
    await page.getByLabel("Provedor", { exact: true }).selectOption("gemini");
    await page
      .getByLabel("Autenticação", { exact: true })
      .selectOption("service_account");
    await expect(
      page.getByLabel("Credencial JSON", { exact: true }),
    ).toBeVisible();
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= window.innerWidth,
      ),
    ).toBeTruthy();
    await page.screenshot({
      path: info.outputPath(`google-service-account-${width}.png`),
      fullPage: true,
    });
  });
}
