from datetime import timedelta
from sqlalchemy import select
from viracase.application.conversation import MAX_BATCHES, prompt_for, apply_batch
from viracase.application.progress import record_progress
from viracase.domain.rules import RuleError, cost, utcnow, validate_files, validate_file_entries
from viracase.infrastructure.models import Attempt, Job, Operation
from viracase.infrastructure.providers import ProviderRejected, ProviderUncertain
from viracase.infrastructure.provider_errors import report_rejection
from viracase.infrastructure.repository import project_dto


def execute_conversation(worker, oid, token):
    repo = worker.repo
    total = {"input": 0, "cached": 0, "output": 0}
    calls, files, original, smaller = [], None, None, False

    def finish(db, op, job, state, error=None):
        try:
            repo.settle_operation(db, op, cost(op.policy, total))
        except RuleError:
            op.state, op.billing_status, op.error_code, job.state = (
                "reconciling",
                "reconciliation_pending",
                "COST_DISCREPANCY",
                "reconciling",
            )
            record_progress(op, "reconciling")
            return
        op.state, op.error_code, job.state = state, error, "done"
        record_progress(op, "proposal_ready" if state == "succeeded" else state)

    for batch in range(MAX_BATCHES):
        with repo.sessions.begin() as db:
            op = db.get(Operation, oid)
            a = repo.account(db, op.account_id, True)
            job = db.scalar(select(Job).where(Job.operation_id == oid).with_for_update())
            if job.lease_token != token:
                return
            db.refresh(op)
            if op.cancel_requested:
                finish(db, op, job, "cancelled")
                return
            try:
                repo.access(db, a, "generate")
                if repo.config.restore_hold or not any(
                    p["model"] == op.policy["model"] and p["version"] == op.policy["version"]
                    for p in worker.catalog.eligible()
                ):
                    raise RuleError("COMMERCIAL_CONFIGURATION_PENDING", "Integração indisponível.")
                p = repo.owned_project(db, a.id, op.project_id)
                if files is None:
                    files = repo.sources.read(
                        repo.owned_revision(db, a.id, p.id, op.payload["base_revision_id"]), p.stack
                    )
                    original = dict(files)
                prompt = prompt_for(
                    project_dto(p),
                    op.payload["brief"],
                    files,
                    batch,
                    smaller,
                    output_tokens=op.policy["max_output_tokens"],
                )
            except RuleError as exc:
                finish(db, op, job, "failed", exc.code)
                return
            policy, stack = dict(op.policy), p.stack
            attempt = db.scalar(select(Attempt).where(Attempt.operation_id == oid))
            if not attempt:
                attempt = Attempt(
                    operation_id=oid, provider=policy["provider"], model=policy["model"], state="sent"
                )
                db.add(attempt)
            # Persist the dispatch BEFORE the network boundary. A crash/timeout is never auto-replayed.
            attempt.state = "sent"
            op.state = "running"
            record_progress(op, "continuing_code" if batch else "provider_sent")
            job.lease_until = utcnow() + timedelta(seconds=repo.config.provider_timeout * 2 + 120)
        try:
            result = worker.gateway.generate(policy, prompt)
        except (ProviderRejected, ProviderUncertain) as exc:
            with repo.sessions.begin() as db:
                op = db.get(Operation, oid)
                repo.account(db, op.account_id, True)
                job = db.scalar(select(Job).where(Job.operation_id == oid).with_for_update())
                if job.lease_token != token:
                    return
                attempt = db.scalar(select(Attempt).where(Attempt.operation_id == oid))
                if isinstance(exc, ProviderUncertain):
                    attempt.state = "uncertain"
                    op.state, op.billing_status, job.state = (
                        "reconciling",
                        "reconciliation_pending",
                        "reconciling",
                    )
                    op.error_code = "PROVIDER_RESULT_UNKNOWN"
                    record_progress(op, "reconciling")
                else:
                    report_rejection(oid, exc)
                    attempt.state = "confirmed"
                    attempt.actual_brl = cost(policy, total)
                    finish(db, op, job, "failed", exc.error_code)
            return
        total = {k: total[k] + result.usage[k] for k in total}
        calls.append(
            {"external_id": result.external_id, "usage": result.usage, "output_error": result.output_error}
        )
        # Complete chunks live only in this job. Never expose or save truncated output as a revision.
        with repo.sessions.begin() as db:
            op = db.get(Operation, oid)
            a = repo.account(db, op.account_id, True)
            job = db.scalar(select(Job).where(Job.operation_id == oid).with_for_update())
            if job.lease_token != token:
                return
            db.refresh(op)
            attempt = db.scalar(select(Attempt).where(Attempt.operation_id == oid))
            attempt.usage, attempt.state, attempt.actual_brl = (
                {**total, "calls": calls},
                "confirmed",
                cost(policy, total),
            )
            attempt.external_id = result.external_id
            if op.cancel_requested:
                finish(db, op, job, "cancelled")
                return
            try:
                repo.access(db, a, "write")
                if result.output_error == "GENERATION_TRUNCATED" and not smaller and batch < MAX_BATCHES - 1:
                    smaller = True
                    record_progress(op, "resizing_code")
                    continue
                if result.output_error:
                    raise RuleError(result.output_error, "Resposta incompleta.")
                next_files, complete = apply_batch(result.text, files)
                validate_file_entries(next_files, repo.sources.secrets)
                if next_files == files and not complete:
                    raise RuleError("GENERATION_NO_CHANGES", "O lote não trouxe alterações.")
                files = next_files
                if not complete:
                    if batch == MAX_BATCHES - 1:
                        raise RuleError(
                            "GENERATION_LIMIT", "A construção excedeu o limite desta solicitação."
                        )
                    record_progress(op, "continuing_code")
                    continue
                changed = [
                    {"path": path, "change": "modified" if path in original else "created"}
                    for path, content in sorted(files.items())
                    if original.get(path) != content
                ]
                if not changed:
                    raise RuleError("GENERATION_NO_CHANGES", "Nenhuma alteração produzida.")
                validate_files(files, stack, repo.sources.secrets)
                p = repo.owned_project(db, a.id, op.project_id)
                r = repo.add_revision(
                    db, p, files, "generation", op.payload["base_revision_id"], proposal=True
                )
                op.result = {
                    **op.result,
                    "revision_id": r.id,
                    "candidate": True,
                    "changed_files": changed,
                    "validation": "structure_checked",
                }
                finish(db, op, job, "succeeded")
            except RuleError as exc:
                finish(db, op, job, "failed", exc.code)
            return
