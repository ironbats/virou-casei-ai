import { useEffect, useRef, useState } from "react";
import { api, ApiError, command } from "../shared/api";
import type { Draft } from "../shared/types";

export function useDraft<T>(path: string, payload: (data: T) => unknown) {
  const [data, render] = useState<T | null>(null),
    [status, setStatus] = useState("Carregando rascunho…"),
    [error, setError] = useState<unknown>(null),
    [conflict, setConflict] = useState<Draft<T> | null>(null);
  const current = useRef<T | null>(null),
    version = useRef(0),
    saved = useRef(""),
    pending = useRef<Promise<void> | null>(null),
    blocked = useRef(false),
    alive = useRef(true),
    serialize = useRef(payload);
  serialize.current = payload;
  function setData(value: T | ((old: T) => T)) {
    if (!current.current) return;
    current.current =
      typeof value === "function"
        ? (value as (old: T) => T)(current.current)
        : value;
    render(current.current);
    setStatus("Alterações no rascunho");
  }
  useEffect(() => {
    alive.current = true;
    api<Draft<T>>(path)
      .then((d) => {
        if (!alive.current) return;
        version.current = d.version;
        current.current = d.data;
        saved.current = JSON.stringify(serialize.current(d.data));
        render(d.data);
        setStatus("Rascunho salvo");
      })
      .catch((e) => {
        if (alive.current) {
          setError(e);
          setStatus("Não foi possível carregar o rascunho");
        }
      });
    return () => {
      alive.current = false;
      current.current = null;
    };
  }, [path]);
  async function flush(): Promise<void> {
    if (pending.current) {
      await pending.current;
      return flush();
    }
    if (blocked.current)
      throw new Error(
        "Compare e resolva o conflito do rascunho antes de continuar.",
      );
    if (!current.current)
      throw new Error("Aguarde o carregamento do rascunho.");
    const body = serialize.current(current.current),
      encoded = JSON.stringify(body);
    if (encoded === saved.current) return;
    setStatus("Salvando rascunho…");
    setError(null);
    pending.current = (async () => {
      try {
        const response = await command<{ version: number }>(
          path,
          body,
          "PUT",
          version.current,
        );
        version.current = response.version;
        saved.current = encoded;
        if (alive.current) setStatus("Rascunho salvo");
      } catch (e) {
        if (alive.current) {
          setError(e);
          setStatus("Rascunho não salvo — conteúdo preservado nesta tela");
          if (e instanceof ApiError && [409, 412].includes(e.status)) {
            blocked.current = true;
            const remote = await api<Draft<T>>(path);
            if (alive.current) setConflict(remote);
          }
        }
        throw e;
      } finally {
        pending.current = null;
      }
    })();
    await pending.current;
    if (
      alive.current &&
      current.current &&
      JSON.stringify(serialize.current(current.current)) !== saved.current
    )
      await flush();
  }
  useEffect(() => {
    if (
      !data ||
      blocked.current ||
      JSON.stringify(serialize.current(data)) === saved.current
    )
      return;
    const timer = setTimeout(() => void flush().catch(() => {}), 700);
    return () => clearTimeout(timer);
  }, [data]);
  useEffect(() => {
    const guard = (event: BeforeUnloadEvent) => {
      if (
        current.current &&
        JSON.stringify(serialize.current(current.current)) !== saved.current
      ) {
        event.preventDefault();
        event.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", guard);
    return () => window.removeEventListener("beforeunload", guard);
  }, []);
  function resolve(remote: boolean) {
    if (!conflict) return;
    version.current = conflict.version;
    saved.current = JSON.stringify(serialize.current(conflict.data));
    blocked.current = false;
    setConflict(null);
    setError(null);
    if (remote) {
      current.current = conflict.data;
      render(conflict.data);
      setStatus("Rascunho recarregado");
    } else {
      render(current.current ? { ...current.current } : null);
      setStatus("Alterações locais prontas para reaplicar");
    }
  }
  return {
    data,
    setData,
    status,
    error,
    conflict,
    resolve,
    flush,
    version: () => version.current,
  };
}
