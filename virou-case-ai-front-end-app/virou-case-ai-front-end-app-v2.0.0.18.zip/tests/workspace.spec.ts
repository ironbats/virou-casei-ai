import { expect, test, type Page } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import { productionPolicy } from "./productionPolicy";

test.beforeEach(async ({ page }) => {
  await productionPolicy(page);
});

test.skip(
  process.env.VIRA_E2E_WORKSPACE !== "true",
  "Use backend/script/test-workspace.py para iniciar o laboratório de construção.",
);

import { workspace } from "./workspaceHelper";

async function send(page: Page, request: string) {
  await page.getByLabel("Pedido para a IA").fill(request);
  await page
    .getByRole("button", { name: "Enviar para IA", exact: true })
    .click();
  const turn = page.locator(".build-turn").last();
  await expect(turn.locator(".build-request")).toContainText(request);
  return turn;
}

test("pedido, progresso real, revisão explícita e histórico após recarga", async ({
  page,
}, info) => {
  await workspace(page);
  const original = await page.locator(".code-editor").inputValue();
  const turn = await send(
    page,
    "Melhorar o título e o conteúdo da página inicial",
  );
  await expect(turn).toHaveAttribute("data-state", "running");
  await expect(turn).toContainText("Construindo as alterações solicitadas.");
  await page.screenshot({
    path: info.outputPath("construction-running.png"),
    fullPage: true,
  });
  await expect(turn).toHaveAttribute("data-state", "succeeded");
  await expect(page.locator(".code-editor")).toHaveValue(original);
  await turn.getByRole("button", { name: "Revisar alterações" }).click();
  await expect(page.getByRole("dialog")).toContainText("public/index.html");
  await page
    .getByRole("button", { name: "Aplicar alterações revisadas" })
    .click();
  await expect(page.getByRole("dialog")).toHaveCount(0);
  await expect(page.locator(".code-editor")).not.toHaveValue(original);
  await expect(turn).toContainText("Estrutura dos arquivos conferida.");
  await expect(page.locator("body")).not.toContainText(/gpt-|gemini|openai/i);
  await page.reload();
  await expect(page.locator(".build-turn").last()).toContainText(
    "Melhorar o título e o conteúdo da página inicial",
  );
  await page.getByRole("button", { name: "Usar texto simples" }).click();
  await expect(page.locator(".code-editor")).toHaveValue(/Alteração E2E/);
  await page.screenshot({
    path: info.outputPath("construction-complete.png"),
    fullPage: true,
  });
  const audit = await new AxeBuilder({ page })
    .include(".ide-layout")
    .withTags(["wcag2a", "wcag2aa"])
    .analyze();
  expect(audit.violations).toEqual([]);
});

test("edição local durante construção é preservada e atualização exige escolha", async ({
  page,
}) => {
  await workspace(page);
  const turn = await send(
    page,
    "Adicionar uma melhoria preservando edição local",
  );
  await expect(turn).toHaveAttribute("data-state", "running");
  await page
    .locator(".code-editor")
    .fill("Minha edição local não pode ser perdida");
  await expect(turn).toHaveAttribute("data-state", "succeeded");
  await expect(page.locator(".code-editor")).toHaveValue(
    "Minha edição local não pode ser perdida",
  );
  await turn.getByRole("button", { name: "Revisar alterações" }).click();
  await expect(
    page.getByRole("button", { name: "Aplicar alterações revisadas" }),
  ).toBeDisabled();
  await page.getByRole("button", { name: "Fechar", exact: true }).click();
  await expect(
    page.getByText("Rascunho salvo", { exact: false }).first(),
  ).toBeVisible();
  await page.reload();
  await page.getByRole("button", { name: "Usar texto simples" }).click();
  await expect(page.locator(".code-editor")).toHaveValue(
    "Minha edição local não pode ser perdida",
  );
  // Explicitly reset the draft for the next independent scenario.
  await page.evaluate(async () => {
    const me = await (await fetch("/api/v1/me")).json();
    const pid = location.pathname.split("/").at(-1);
    const draft = await (await fetch(`/api/v1/projects/${pid}/draft`)).json();
    await fetch(`/api/v1/projects/${pid}/draft`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        "X-CSRF-Token": me.csrf_token,
        "Idempotency-Key": crypto.randomUUID(),
        "If-Match": String(draft.version),
      },
      body: JSON.stringify({
        ...draft.data,
        files: null,
        provenance: undefined,
      }),
    });
  });
});

test("resposta truncada preserva revisão e permite reutilizar pedido", async ({
  page,
}) => {
  await workspace(page);
  const original = await page.locator(".code-editor").inputValue();
  const turn = await send(
    page,
    "SIMULAR_TRUNCADO para validar recuperação do pedido",
  );
  await expect(turn).toHaveAttribute("data-state", "failed", {
    timeout: 15000,
  });
  await expect(turn).toContainText("limite de tamanho");
  await expect(page.locator(".code-editor")).toHaveValue(original);
  await turn.getByRole("button", { name: "Reutilizar pedido" }).click();
  await expect(page.getByLabel("Pedido para a IA")).toHaveValue(
    "SIMULAR_TRUNCADO para validar recuperação do pedido",
  );
  await expect(
    page.getByRole("button", { name: "Enviar para IA", exact: true }),
  ).toBeEnabled();
});

test("cancelamento durante construção não aplica os arquivos", async ({
  page,
}) => {
  await workspace(page);
  const original = await page.locator(".code-editor").inputValue();
  const turn = await send(
    page,
    "Construir página para validar cancelamento em andamento",
  );
  await expect(turn).toHaveAttribute("data-state", "running");
  await turn.getByRole("button", { name: "Cancelar construção" }).click();
  await expect(turn).toHaveAttribute("data-state", "cancelled");
  await expect(turn).toContainText("não foi aplicada");
  await expect(page.locator(".code-editor")).toHaveValue(original);
});

test("reconecta sem repetir a geração após falha de acompanhamento", async ({
  page,
}) => {
  await workspace(page);
  let posts = 0;
  page.on("request", (request) => {
    if (request.method() === "POST" && request.url().includes("/conversation"))
      posts += 1;
  });
  const turn = await send(
    page,
    "Atualizar página para validar reconexão sem duplicar operação",
  );
  await page.route("**/api/v1/operations?**", (route) => route.abort("failed"));
  await expect(
    page.getByRole("alert").filter({ hasText: "último estado foi preservado" }),
  ).toBeVisible();
  await expect(turn.locator(".build-request")).toContainText(
    "validar reconexão",
  );
  await page.unroute("**/api/v1/operations?**");
  await page.getByRole("button", { name: "Reconectar", exact: true }).click();
  await expect(turn).toHaveAttribute("data-state", "succeeded");
  expect(posts).toBe(1);
});

test("conversa acessível em mobile, tablet e desktop sem overflow", async ({
  page,
}, info) => {
  await workspace(page);
  for (const width of [320, 375, 768, 1024, 1440]) {
    await page.setViewportSize({ width, height: 900 });
    if (width <= 900)
      await page.getByRole("tab", { name: "Conversa", exact: true }).click();
    await expect(
      page.getByRole("region", { name: "Conversa de construção" }),
    ).toBeVisible();
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
    expect(
      await page.evaluate(
        () =>
          document.documentElement.scrollHeight <=
          Math.max(
            innerHeight,
            document.querySelector("#main")!.getBoundingClientRect().bottom +
              scrollY +
              2,
          ),
      ),
    ).toBe(true);
    if (width === 375 || width === 1440)
      await page.screenshot({
        path: info.outputPath(`workspace-${width}.png`),
        fullPage: true,
      });
  }
  await page.setViewportSize({ width: 375, height: 900 });
  await page.getByRole("tab", { name: "Conversa", exact: true }).click();
  const audit = await new AxeBuilder({ page })
    .include(".ide-layout")
    .withTags(["wcag2a", "wcag2aa"])
    .analyze();
  expect(audit.violations).toEqual([]);
});

test("acompanha até concluir uma operação fora da primeira página", async ({
  page,
}) => {
  await workspace(page);
  await page.route("**/api/v1/operations?**", async (route) => {
    const url = new URL(route.request().url());
    if (url.searchParams.has("state")) return route.continue();
    const response = await route.fetch();
    const body = await response.json();
    body.items = body.items.filter(
      (item: { request_text?: string }) =>
        !item.request_text?.includes("FORA_DA_PAGINA"),
    );
    await route.fulfill({ response, json: body });
  });
  const turn = await send(
    page,
    "FORA_DA_PAGINA melhorar a experiência da página inicial",
  );
  await expect(turn).toHaveAttribute("data-state", "running");
  await expect(turn).toHaveAttribute("data-state", "succeeded");
});

test("recupera corte confirmado e oferece código para revisão", async ({
  page,
}) => {
  await workspace(page);
  const original = await page.locator(".code-editor").inputValue();
  const turn = await send(
    page,
    "RECUPERAR_CORTE implementar a melhoria completa",
  );
  await expect(turn).toHaveAttribute("data-state", "succeeded", {
    timeout: 15000,
  });
  await expect(page.locator(".code-editor")).toHaveValue(original);
  await turn.getByRole("button", { name: "Revisar alterações" }).click();
  await expect(page.getByRole("dialog")).toContainText("Alteração E2E");
  await page.getByRole("button", { name: "Fechar", exact: true }).click();
});

test("guia SDD, edição manual, recarga e transferência sem gerar IA", async ({
  page,
  context,
}, info) => {
  await context.grantPermissions(["clipboard-read", "clipboard-write"]);
  const project = await workspace(page);
  let generations = 0;
  page.on("request", (r) => {
    if (r.method() === "POST" && r.url().includes("/conversation"))
      generations++;
  });
  await page.getByRole("link", { name: "Explorar guias" }).click();
  await expect(page.locator(".guide-card")).toHaveCount(14);
  await page.getByRole("tab", { name: "2 Adapte" }).click();
  await page
    .getByLabel("Objetivo do projeto")
    .fill("Criar um organizador de tarefas da equipe");
  await page.getByLabel("Para quem é o projeto?").fill("Equipe de operações");
  await page
    .getByLabel("Critérios de aceite")
    .fill("Cadastrar tarefa, concluir tarefa e ver a lista atualizada.");
  await page.getByRole("button", { name: "Revisar e aplicar" }).click();
  await page
    .getByLabel("Revise e edite o texto")
    .fill(
      "Pedido manual: implemente tarefas completas e preserve o histórico.",
    );
  await page.getByRole("tab", { name: "2 Adapte" }).click();
  await page
    .getByLabel("Objetivo do projeto")
    .fill("Objetivo atualizado sem apagar meu prompt");
  await page.getByRole("tab", { name: "3 Aplique" }).click();
  await expect(page.getByLabel("Revise e edite o texto")).toHaveValue(
    "Pedido manual: implemente tarefas completas e preserve o histórico.",
  );
  await expect(page.getByText("Rascunho salvo", { exact: true })).toBeVisible();
  await page.reload();
  await page.getByRole("tab", { name: "3 Aplique" }).click();
  await page.getByRole("button", { name: "Copiar template" }).click();
  expect(await page.evaluate(() => navigator.clipboard.readText())).toBe(
    "Pedido manual: implemente tarefas completas e preserve o histórico.",
  );
  await page.screenshot({
    path: info.outputPath("learning-apply-desktop.png"),
    fullPage: true,
  });
  expect(
    (
      await new AxeBuilder({ page })
        .include(".learning-workspace")
        .withTags(["wcag2a", "wcag2aa"])
        .analyze()
    ).violations,
  ).toEqual([]);
  await page
    .getByRole("button", { name: "Levar rascunho para o projeto" })
    .click();
  await expect(page).toHaveURL(new RegExp(`/app/projetos/${project.id}`));
  await expect(page.getByLabel("Pedido para a IA")).toHaveValue(
    "Pedido manual: implemente tarefas completas e preserve o histórico.",
  );
  await expect(page.getByLabel("Pedido para a IA")).toBeFocused();
  expect(generations).toBe(0);
  await page.getByRole("link", { name: "Explorar guias" }).click();
  await page.getByRole("tab", { name: "3 Aplique" }).click();
  await page
    .getByRole("button", { name: "Levar rascunho para o projeto" })
    .click();
  await expect(page.getByRole("dialog")).toContainText("Já existe um rascunho");
  await page.getByRole("button", { name: "Acrescentar ao rascunho" }).click();
  await expect(page.getByLabel("Pedido para a IA")).toHaveValue(
    /histórico\.\n\nPedido manual/,
  );
  expect(generations).toBe(0);
});

test("conflito de rascunho preserva as duas versões e permite comparação", async ({
  page,
}) => {
  const project = await workspace(page);
  await page.evaluate(async (pid) => {
    const me = await (await fetch("/api/v1/me")).json();
    const draft = await (await fetch(`/api/v1/projects/${pid}/draft`)).json();
    const r = await fetch(`/api/v1/projects/${pid}/draft`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        "X-CSRF-Token": me.csrf_token,
        "Idempotency-Key": crypto.randomUUID(),
        "If-Match": String(draft.version),
      },
      body: JSON.stringify({
        base_revision_id: draft.data.base_revision_id,
        files: draft.data.files,
        prompt: "Texto salvo em outra sessão",
      }),
    });
    if (!r.ok) throw new Error(await r.text());
  }, project.id);
  await page
    .getByLabel("Pedido para a IA")
    .fill("Meu texto nesta sessão deve ser preservado");
  await expect(page.getByRole("dialog")).toContainText(
    "Texto salvo em outra sessão",
  );
  await expect(page.getByRole("dialog")).toContainText(
    "Meu texto nesta sessão deve ser preservado",
  );
  await page.getByRole("button", { name: "Reaplicar meu rascunho" }).click();
  await expect(
    page.getByText("Rascunho salvo", { exact: false }).first(),
  ).toBeVisible();
  await page.reload();
  await expect(page.getByLabel("Pedido para a IA")).toHaveValue(
    "Meu texto nesta sessão deve ser preservado",
  );
});

test("Aprender em mobile preserva filtros e rascunho", async ({
  page,
}, info) => {
  await workspace(page);
  await page.setViewportSize({ width: 375, height: 812 });
  await page.goto("/app/aprendizado");
  await page.getByLabel("Buscar guias").fill("SDD");
  await expect(page.locator(".guide-card")).toHaveCount(1);
  await page.getByRole("link", { name: "Ver guia" }).click();
  await page.getByRole("tab", { name: "2 Adapte" }).click();
  await expect(page.getByLabel("Objetivo do projeto")).toHaveValue(
    "Objetivo atualizado sem apagar meu prompt",
  );
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await page.screenshot({
    path: info.outputPath("learning-mobile.png"),
    fullPage: true,
  });
  expect(
    (
      await new AxeBuilder({ page })
        .include(".learning-workspace")
        .withTags(["wcag2a", "wcag2aa"])
        .analyze()
    ).violations,
  ).toEqual([]);
  await page.getByRole("link", { name: "Voltar aos guias" }).click();
  await expect(page.getByLabel("Buscar guias")).toHaveValue("SDD");
});

test("editor com destaque, abas e teclado preserva conteúdo", async ({
  page,
}, info) => {
  await workspace(page);
  await page.getByRole("button", { name: "Editor com destaque" }).click();
  await expect(page.locator(".cm-lineNumbers")).toBeVisible();
  await page.getByRole("treeitem", { name: "app.js", exact: true }).click();
  await expect(page.locator(".cm-content")).toHaveAttribute(
    "aria-label",
    "Conteúdo de public/app.js",
  );
  const before = await page.locator(".cm-content").innerText();
  await page.locator(".cm-content").click();
  await page.keyboard.press("Control+End");
  await page.keyboard.insertText("\n// Edição preservada no rascunho");
  await page.getByRole("treeitem", { name: "index.html", exact: true }).click();
  await page.getByRole("tab", { name: /app.js/ }).click();
  await expect(page.locator(".cm-content")).toContainText(
    "Edição preservada no rascunho",
  );
  await page.locator(".cm-content").click();
  await page.keyboard.press("Escape");
  await page.keyboard.press("Tab");
  await expect(page.locator(".cm-content")).not.toBeFocused();
  expect(
    (
      await new AxeBuilder({ page })
        .include(".ide-layout")
        .withTags(["wcag2a", "wcag2aa"])
        .analyze()
    ).violations,
  ).toEqual([]);
  await page.screenshot({
    path: info.outputPath("editor-highlighted.png"),
    fullPage: true,
  });
  await page.getByRole("button", { name: "Usar texto simples" }).click();
  await page.locator(".code-editor").fill(before);
  await expect(
    page.getByText("Rascunho salvo", { exact: false }).first(),
  ).toBeVisible();
});

test("pedido acima do limite é preservado e não dispara geração", async ({
  page,
}) => {
  await workspace(page);
  const text = "x".repeat(12001);
  let posts = 0;
  page.on("request", (r) => {
    if (r.method() === "POST" && r.url().includes("/conversation")) posts++;
  });
  await page.getByLabel("Pedido para a IA").fill(text);
  await expect(page.getByLabel("Pedido para a IA")).toHaveValue(text);
  await expect(
    page.getByRole("button", { name: "Enviar para IA", exact: true }),
  ).toBeDisabled();
  await page.getByLabel("Pedido para a IA").press("Control+Enter");
  expect(posts).toBe(0);
  await page.getByLabel("Pedido para a IA").fill("");
  await expect(
    page.getByText("Rascunho salvo", { exact: false }).first(),
  ).toBeVisible();
});

test("resultado incerto bloqueia reenvio e persiste após recarga", async ({
  page,
}) => {
  await workspace(page);
  const turn = await send(
    page,
    "SIMULAR_INCERTO para validar resultado em apuração",
  );
  await expect(turn).toHaveAttribute("data-state", "reconciling");
  await expect(turn).toContainText("resultado está em apuração");
  await expect(
    turn.getByRole("button", { name: "Reutilizar pedido" }),
  ).toHaveCount(0);
  await page.reload();
  await expect(page.locator(".build-turn").last()).toHaveAttribute(
    "data-state",
    "reconciling",
  );
  await page
    .getByLabel("Pedido para a IA")
    .fill("Novo pedido que precisa aguardar a apuração");
  await expect(
    page.getByRole("button", { name: "Construindo…" }),
  ).toBeDisabled();
});
